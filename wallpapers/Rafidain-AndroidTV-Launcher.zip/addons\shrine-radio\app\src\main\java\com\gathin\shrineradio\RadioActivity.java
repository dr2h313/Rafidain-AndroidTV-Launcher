package com.gathin.shrineradio;

import android.app.Activity;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RadioActivity extends Activity {

    public static class Station {
        public final String title;
        public final String subtitle;
        public final String icon;
        public final String url;

        public Station(String title, String subtitle, String icon, String url) {
            this.title = title;
            this.subtitle = subtitle;
            this.icon = icon;
            this.url = url;
        }
    }

    private static final Station[] STATIONS = {
        new Station("إذاعة الروضة الحسينية المقدسة", "بث مباشر مستمر · كربلاء المقدسة", "🕌", "https://www.imamhussain-fm.com/radio/stream"),
        new Station("إذاعة التلاوات الخاشعة", "بث مباشر مستمر · إذاعة القرآن الكريم", "📖", "https://backup.qurango.net/radio/salma"),
        new Station("الحاج عامر الكاظمي - سورة الكهف", "تلاوة كاملة بالمقام والطور العراقي", "✨", "https://archive.org/download/Way2sona_20151221_1450/018.mp3"),
        new Station("الحاج عامر الكاظمي - سورة يس", "تلاوة كاملة بالمقام والطور العراقي", "✨", "https://archive.org/download/Way2sona_20151221_1450/036.mp3"),
        new Station("الحاج عامر الكاظمي - سورة الرحمن", "تلاوة كاملة بالمقام والطور العراقي", "✨", "https://archive.org/download/Way2sona_20151221_1450/055.mp3"),
        new Station("الحاج عامر الكاظمي - سورة الملك", "تلاوة كاملة بالمقام والطور العراقي", "✨", "https://archive.org/download/Way2sona_20151221_1450/067.mp3"),
        new Station("ميثم التمار - سورة الكهف", "تلاوة عراقية خاشعة شجية", "🌙", "https://archive.org/download/Quran_maythamAlTammar/Quran18.mp3"),
        new Station("ميثم التمار - سورة يس", "تلاوة عراقية خاشعة شجية", "🌙", "https://archive.org/download/Quran_maythamAlTammar/Quran36.mp3"),
        new Station("ميثم التمار - سورة الرحمن", "تلاوة عراقية خاشعة شجية", "🌙", "https://archive.org/download/Quran_maythamAlTammar/Quran55.mp3"),
        new Station("ميثم التمار - سورة الواقعة", "تلاوة عراقية خاشعة شجية", "🌙", "https://archive.org/download/Quran_maythamAlTammar/Quran56.mp3"),
        new Station("ميثم التمار - سورة الملك", "تلاوة عراقية خاشعة شجية", "🌙", "https://archive.org/download/Quran_maythamAlTammar/Quran67.mp3")
    };

    private MediaPlayer mediaPlayer = null;
    private int currentIndex = 0;
    private boolean isPreparing = false;

    private TextView currentTitle;
    private TextView currentSubtitle;
    private TextView shrineIcon;
    private TextView statusPill;
    private Button btnPlayPause;
    private Button btnPrev;
    private Button btnNext;
    private LinearLayout stationListContainer;
    private View[] visualizerBars;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private final Runnable visualizerRunnable = new Runnable() {
        @Override
        public void run() {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                for (View bar : visualizerBars) {
                    int heightDp = 6 + random.nextInt(26);
                    int heightPx = (int) (heightDp * getResources().getDisplayMetrics().density);
                    ViewGroup.LayoutParams lp = bar.getLayoutParams();
                    lp.height = heightPx;
                    bar.setLayoutParams(lp);
                }
                handler.postDelayed(this, 120);
            } else {
                for (View bar : visualizerBars) {
                    int heightPx = (int) (6 * getResources().getDisplayMetrics().density);
                    ViewGroup.LayoutParams lp = bar.getLayoutParams();
                    lp.height = heightPx;
                    bar.setLayoutParams(lp);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio);

        currentTitle = findViewById(R.id.currentTitle);
        currentSubtitle = findViewById(R.id.currentSubtitle);
        shrineIcon = findViewById(R.id.shrineIcon);
        statusPill = findViewById(R.id.statusPill);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        stationListContainer = findViewById(R.id.stationListContainer);

        visualizerBars = new View[]{
            findViewById(R.id.bar1),
            findViewById(R.id.bar2),
            findViewById(R.id.bar3),
            findViewById(R.id.bar4),
            findViewById(R.id.bar5)
        };

        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnPrev.setOnClickListener(v -> playPrev());
        btnNext.setOnClickListener(v -> playNext());

        populateStationList();
        updateStationDisplay();

        btnPlayPause.requestFocus();
    }

    private void populateStationList() {
        stationListContainer.removeAllViews();
        int pad = (int) (14 * getResources().getDisplayMetrics().density);
        int margin = (int) (8 * getResources().getDisplayMetrics().density);

        for (int i = 0; i < STATIONS.length; i++) {
            final int index = i;
            Station st = STATIONS[i];

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setPadding(pad, pad, pad, pad);
            item.setFocusable(true);
            item.setClickable(true);
            item.setBackgroundResource(R.drawable.bg_item_focus);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lp.bottomMargin = margin;
            item.setLayoutParams(lp);

            TextView iconTv = new TextView(this);
            iconTv.setText(st.icon);
            iconTv.setTextSize(22);
            iconTv.setPadding(0, 0, 16, 0);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);

            TextView titleTv = new TextView(this);
            titleTv.setText(st.title);
            titleTv.setTextSize(16);
            titleTv.setTextColor(Color.WHITE);

            TextView subTv = new TextView(this);
            subTv.setText(st.subtitle);
            subTv.setTextSize(12);
            subTv.setTextColor(Color.parseColor("#94A3B8"));

            textCol.addView(titleTv);
            textCol.addView(subTv);

            item.addView(iconTv);
            item.addView(textCol);

            item.setOnClickListener(v -> playStation(index));

            stationListContainer.addView(item);
        }
    }

    private void updateStationDisplay() {
        if (currentIndex < 0 || currentIndex >= STATIONS.length) return;
        Station st = STATIONS[currentIndex];
        currentTitle.setText(st.title);
        currentSubtitle.setText(st.subtitle);
        shrineIcon.setText(st.icon);
    }

    private void playStation(int index) {
        if (index < 0 || index >= STATIONS.length) return;
        currentIndex = index;
        updateStationDisplay();

        stopPlayer();
        isPreparing = true;
        statusPill.setText("⏳ جاري الاتصال والتحميل...");
        btnPlayPause.setText("⏳ تحميل");

        Station st = STATIONS[currentIndex];
        Toast.makeText(this, "📻 " + st.title, Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                MediaPlayer mp = new MediaPlayer();
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build());

                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "Mozilla/5.0 (Android TV; Leanback)");
                mp.setDataSource(RadioActivity.this, Uri.parse(st.url), headers);

                mp.setOnPreparedListener(player -> {
                    handler.post(() -> {
                        isPreparing = false;
                        mediaPlayer = player;
                        player.start();
                        statusPill.setText("🟢 يعمل الآن");
                        btnPlayPause.setText("⏸️ إيقاف مؤقت");
                        handler.post(visualizerRunnable);
                    });
                });

                mp.setOnCompletionListener(player -> {
                    handler.post(() -> {
                        statusPill.setText("⏹️ انتهت التلاوة");
                        btnPlayPause.setText("▶️ تشغيل");
                        stopPlayer();
                    });
                });

                mp.setOnErrorListener((player, what, extra) -> {
                    handler.post(() -> {
                        isPreparing = false;
                        statusPill.setText("⚠️ تعذر تشغيل المحطة");
                        btnPlayPause.setText("▶️ إعادة المحاولة");
                        stopPlayer();
                    });
                    return true;
                });

                mp.prepareAsync();
            } catch (Exception e) {
                handler.post(() -> {
                    isPreparing = false;
                    statusPill.setText("⚠️ خطأ في الاتصال");
                    btnPlayPause.setText("▶️ تشغيل");
                    stopPlayer();
                });
            }
        }).start();
    }

    private void togglePlayPause() {
        if (isPreparing) return;
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                statusPill.setText("⏸️ متوقف مؤقتاً");
                btnPlayPause.setText("▶️ استئناف");
            } else {
                mediaPlayer.start();
                statusPill.setText("🟢 يعمل الآن");
                btnPlayPause.setText("⏸️ إيقاف مؤقت");
                handler.post(visualizerRunnable);
            }
        } else {
            playStation(currentIndex);
        }
    }

    private void playNext() {
        int next = (currentIndex + 1) % STATIONS.length;
        playStation(next);
    }

    private void playPrev() {
        int prev = (currentIndex - 1 + STATIONS.length) % STATIONS.length;
        playStation(prev);
    }

    private void stopPlayer() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.reset();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
        handler.removeCallbacks(visualizerRunnable);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY || keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
            togglePlayPause();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            playNext();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            playPrev();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MEDIA_STOP) {
            stopPlayer();
            statusPill.setText("⏹️ متوقف");
            btnPlayPause.setText("▶️ تشغيل");
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }
}
