package io.github.sumyabazar1.weather;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.time.format.TextStyle;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WeatherActivity extends Activity {
    private static final String PREFS = "place";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable tick = this::refresh;
    private SharedPreferences place;
    private View root;
    private View content;
    private TextView message;
    private boolean shown;
    private int forecastDays;
    private boolean fahrenheit;

    private static String getWeatherEmoji(int code, boolean isDay) {
        switch (code) {
            case 0:
                return isDay ? "☀️" : "🌙";
            case 1:
            case 2:
                return isDay ? "🌤️" : "☁️";
            case 3:
                return "☁️";
            case 45:
            case 48:
                return "🌫️";
            case 51:
            case 53:
            case 55:
            case 56:
            case 57:
                return "🌦️";
            case 61:
            case 63:
            case 65:
            case 66:
            case 67:
                return "🌧️";
            case 71:
            case 73:
            case 75:
            case 77:
                return "❄️";
            case 80:
            case 81:
            case 82:
                return "🌧️";
            case 85:
            case 86:
                return "🌨️";
            case 95:
            case 96:
            case 99:
                return "⛈️";
            default:
                return isDay ? "☀️" : "🌙";
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_weather);
        place = getSharedPreferences(PREFS, MODE_PRIVATE);
        forecastDays = 7;
        fahrenheit = "f".equalsIgnoreCase(getString(R.string.temperature_unit).trim());
        root = findViewById(R.id.root);
        content = findViewById(R.id.content);
        message = findViewById(R.id.message);

        View changeCity = findViewById(R.id.changeCity);
        changeCity.setOnClickListener(v -> showCityMenu());
        changeCity.requestFocus();

        View btnRefresh = findViewById(R.id.btnRefresh);
        if (btnRefresh != null) {
            btnRefresh.setOnClickListener(v -> {
                Toast.makeText(this, "🔄 جاري تحديث بيانات الطقس...", Toast.LENGTH_SHORT).show();
                refresh();
            });
        }

        if (!place.contains("name")) {
            place.edit()
                .putString("name", "البصرة - شط العرب والنشوة")
                .putLong("lat", Double.doubleToRawLongBits(30.8095))
                .putLong("lon", Double.doubleToRawLongBits(47.6088))
                .putString("country", "العراق")
                .apply();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (place.contains("name")) refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        main.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    private void refresh() {
        main.removeCallbacks(tick);
        double lat = Double.longBitsToDouble(place.getLong("lat", 0));
        double lon = Double.longBitsToDouble(place.getLong("lon", 0));
        io.execute(() -> {
            Forecast.Report report;
            try {
                report = Forecast.fetch(lat, lon, forecastDays);
            } catch (Exception e) {
                report = null;
            }
            Forecast.Report result = report;
            main.post(() -> {
                if (isDestroyed()) return;
                if (result != null) show(result);
                else if (!shown) message.setText(R.string.offline);
                main.postDelayed(tick, result != null ? Forecast.REFRESH_MS : Forecast.RETRY_MS);
            });
        });
    }

    private void show(Forecast.Report r) {
        shown = true;
        root.setBackground(Forecast.backdrop(r.code, r.day));

        // Location & Main Temp
        ((TextView) findViewById(R.id.place)).setText("📍 " + place.getString("name", "البصرة"));
        ((TextView) findViewById(R.id.temp)).setText(Forecast.degrees(r.tempC, fahrenheit) + "°");
        ((TextView) findViewById(R.id.sky)).setText(Forecast.sky(r.code, r.day));

        TextView skyIcon = findViewById(R.id.skyIcon);
        if (skyIcon != null) {
            skyIcon.setText(getWeatherEmoji(r.code, r.day));
        }

        // Feels like & High/Low
        String feelsStr = getString(R.string.feels_like, Forecast.degrees(r.feelsC, fahrenheit));
        if (r.days != null && !r.days.isEmpty()) {
            Forecast.Day today = r.days.get(0);
            feelsStr += " · العظمى " + Forecast.degrees(today.maxC, fahrenheit) + "° / الصغرى " + Forecast.degrees(today.minC, fahrenheit) + "°";
        }
        ((TextView) findViewById(R.id.feels)).setText(feelsStr);

        // 6 Metrics
        TextView mHumidity = findViewById(R.id.metricHumidity);
        if (mHumidity != null) mHumidity.setText(r.humidity + "%");

        TextView mWind = findViewById(R.id.metricWind);
        if (mWind != null) {
            String dirStr = Forecast.windDirection(r.windDirectionDeg);
            String wText = r.windKmh + " كم/س (" + dirStr + ")";
            if (r.windGustsKmh > r.windKmh) {
                wText += " · هبات " + r.windGustsKmh;
            }
            mWind.setText(wText);
        }

        TextView mDust = findViewById(R.id.metricDust);
        if (mDust != null) {
            if (r.dustMgM3 >= 0) {
                mDust.setText(Math.round(r.dustMgM3) + " ميكروغرام/م³");
            } else {
                mDust.setText("طبيعي ومستقر");
            }
        }

        TextView mAqi = findViewById(R.id.metricAqi);
        if (mAqi != null) {
            if (r.aqi >= 0) {
                mAqi.setText(r.aqi + " · " + getString(Forecast.aqiLabel(r.aqi)));
                mAqi.setTextColor(Forecast.aqiTextColour(r.aqi));
            } else {
                mAqi.setText("طبيعي ومقبول");
                mAqi.setTextColor(Color.parseColor("#4ADE80"));
            }
        }

        TextView mPressure = findViewById(R.id.metricPressure);
        if (mPressure != null) mPressure.setText(r.surfacePressureHpa + " hPa");

        TextView mRain = findViewById(R.id.metricRain);
        if (mRain != null) {
            if (r.precipitationMm > 0.05) {
                mRain.setText(String.format(Locale.ROOT, "%.1f ملم هطول", r.precipitationMm));
            } else {
                mRain.setText("0.0 ملم (لا توجد)");
            }
        }

        // 7-Day Forecast Cards
        LinearLayout daysContainer = findViewById(R.id.days);
        daysContainer.removeAllViews();
        LayoutInflater inflater = getLayoutInflater();

        for (int i = 0; i < r.days.size(); i++) {
            Forecast.Day d = r.days.get(i);
            View card = inflater.inflate(R.layout.item_day, daysContainer, false);

            TextView dayName = card.findViewById(R.id.dayName);
            if (i == 0) {
                dayName.setText("اليوم");
            } else if (i == 1) {
                dayName.setText("غداً");
            } else {
                dayName.setText(d.date.getDayOfWeek().getDisplayName(TextStyle.FULL, new Locale("ar")));
            }

            TextView dayIcon = card.findViewById(R.id.dayIcon);
            if (dayIcon != null) {
                dayIcon.setText(getWeatherEmoji(d.code, true));
            }

            TextView daySky = card.findViewById(R.id.daySky);
            daySky.setText(Forecast.sky(d.code, true));

            TextView dayTemps = card.findViewById(R.id.dayTemps);
            dayTemps.setText(Forecast.degrees(d.maxC, fahrenheit) + "° / " + Forecast.degrees(d.minC, fahrenheit) + "°");

            daysContainer.addView(card);
        }

        ((TextView) findViewById(R.id.updated))
                .setText(getString(R.string.updated, DateFormat.getTimeFormat(this).format(new Date())));
        message.setVisibility(View.GONE);
        content.setVisibility(View.VISIBLE);
    }

    private void showCityMenu() {
        String[] cities = {
            "📍 قضاء شط العرب والنشوة (البصرة)",
            "📍 مركز مدينة البصرة (العشار والمعقل)",
            "📍 قضاء الزبير (البصرة)",
            "📍 قضاء القرنة (ملتقى الرافدين)",
            "📍 قضاء الفاو (أقصى جنوب العراق)",
            "📍 العاصمة بغداد",
            "📍 كربلاء المقدسة",
            "📍 النجف الأشرف",
            "🔍 بحث مخصص عن أي مدينة أو قضاء..."
        };

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("اختر المنطقة أو القضاء")
            .setItems(cities, (dialog, which) -> {
                if (which == 0) {
                    setCoordinates("البصرة - شط العرب والنشوة", 30.8095, 47.6088);
                } else if (which == 1) {
                    setCoordinates("مركز مدينة البصرة", 30.5085, 47.8183);
                } else if (which == 2) {
                    setCoordinates("قضاء الزبير - البصرة", 30.3908, 47.7028);
                } else if (which == 3) {
                    setCoordinates("قضاء القرنة - البصرة", 31.0084, 47.4332);
                } else if (which == 4) {
                    setCoordinates("قضاء الفاو - البصرة", 29.9742, 48.4731);
                } else if (which == 5) {
                    setCoordinates("بغداد - العاصمة", 33.3152, 44.3661);
                } else if (which == 6) {
                    setCoordinates("كربلاء المقدسة", 32.6160, 44.0249);
                } else if (which == 7) {
                    setCoordinates("النجف الأشرف", 32.0259, 44.3462);
                } else {
                    pickCity();
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void setCoordinates(String name, double lat, double lon) {
        place.edit()
            .putString("name", name)
            .putLong("lat", Double.doubleToRawLongBits(lat))
            .putLong("lon", Double.doubleToRawLongBits(lon))
            .apply();
        message.setText(R.string.loading);
        message.setVisibility(View.VISIBLE);
        refresh();
    }

    private void pickCity() {
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint(R.string.pick_hint);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        name.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        int pad = Math.round(24 * getResources().getDisplayMetrics().density);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.pick_title)
                .setView(box)
                .setPositiveButton(R.string.pick_search, (d, w) -> search(name.getText().toString()))
                .create();
        name.setOnEditorActionListener((v, action, event) -> {
            if (action != EditorInfo.IME_ACTION_SEARCH) return false;
            dialog.dismiss();
            search(name.getText().toString());
            return true;
        });
        dialog.show();
        name.requestFocus();
    }

    private void search(String typed) {
        if (typed.trim().isEmpty()) {
            pickCity();
            return;
        }
        io.execute(() -> {
            List<Forecast.Place> found;
            try {
                found = Forecast.search(typed);
            } catch (Exception e) {
                found = null;
            }
            List<Forecast.Place> places = found;
            main.post(() -> {
                if (isDestroyed()) return;
                if (places == null) {
                    Toast.makeText(this, R.string.offline, Toast.LENGTH_LONG).show();
                } else if (places.isEmpty()) {
                    Toast.makeText(this, getString(R.string.pick_none, typed.trim()), Toast.LENGTH_LONG).show();
                    pickCity();
                } else {
                    choose(places);
                }
            });
        });
    }

    private void choose(List<Forecast.Place> places) {
        CharSequence[] rows = new CharSequence[places.size()];
        for (int i = 0; i < rows.length; i++) {
            Forecast.Place p = places.get(i);
            rows[i] = p.detail.isEmpty() ? p.name : p.name + " · " + p.detail;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.pick_title)
                .setItems(rows, (d, which) -> {
                    Forecast.Place p = places.get(which);
                    setCoordinates(p.name, p.latitude, p.longitude);
                })
                .show();
    }
}
